<?php
$password = "123456";
$md5_hash = md5($password);
echo "MD5 Hash: " . $md5_hash;
?>